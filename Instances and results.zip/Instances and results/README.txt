Each file is organized as follows:

line 1: number n of tasks

lines 2,...,n+1: integer task processing times

lines n+2,...: direct precedence relations in form "i,j"

-1,-1 Indicates that the precedence list is complete

The next line is a random permutation of the set {1,...,n}, which serves for identifying tasks with uncertain processing time.

The following double is the cycle time.

Next comes m, the number of workstations.

Finally, the last line is a random permutation of the set {1,...,m}, which serves for identifying uncertain workstations.
